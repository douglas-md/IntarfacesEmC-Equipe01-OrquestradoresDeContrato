using System;
using System.Collections.Generic;
using System.Text;

namespace OrquestradoresDoContrato.Fase12
{
    // --- Implementações Concretas dos Eixos ---

    public class NoOpFilter : IFilter
    {
        public string Name => "NoOpFilter";
        public bool ShouldProcess(string data) => true;
    }

    public class SensitiveDataFilter : IFilter
    {
        public string Name => "SensitiveDataFilter";
        public bool ShouldProcess(string data)
        {
            // Lógica de filtragem: só processa se não for muito longo
            return data.Length < 1000;
        }
    }

    public class ZipCompressor : ICompressor
    {
        public string Name => "ZipCompressor";
        public byte[] Compress(string data)
        {
            // Simula compressão Zip (apenas retorna bytes do texto)
            Console.WriteLine("-> Comprimindo com Zip...");
            return Encoding.UTF8.GetBytes(data);
        }
    }

    public class GzipCompressor : ICompressor
    {
        public string Name => "GzipCompressor";
        public byte[] Compress(string data)
        {
            // Simula compressão Gzip (apenas retorna bytes do texto)
            Console.WriteLine("-> Comprimindo com Gzip...");
            return Encoding.UTF8.GetBytes(data);
        }
    }

    public class S3Storage : IStorage
    {
        public string Name => "S3Storage";
        public string Store(byte[] compressedData)
        {
            // Simula armazenamento no S3
            Console.WriteLine($"-> Armazenando {compressedData.Length} bytes no S3.");
            return $"s3://bucket-name/{Guid.NewGuid()}.bin";
        }
    }

    public class LocalFileSystemStorage : IStorage
    {
        public string Name => "LocalFileSystemStorage";
        public string Store(byte[] compressedData)
        {
            // Simula armazenamento em disco local
            Console.WriteLine($"-> Armazenando {compressedData.Length} bytes no disco local.");
            return $"/var/data/{Guid.NewGuid()}.bin";
        }
    }

    // --- Implementações dos Repositórios ---

    public class InMemoryPolicyRepository : IPolicyRepository
    {
        private readonly Dictionary<ReportType, ProcessingPolicy> _policies = new Dictionary<ReportType, ProcessingPolicy>
        {
            // Política Válida 1: Financeiro - Filtrar, Zipar, S3
            { ReportType.Financial, new ProcessingPolicy(ReportType.Financial, "SensitiveDataFilter", "ZipCompressor", "S3Storage") },
            // Política Válida 2: Marketing - Não Filtrar, Gzipar, Local
            { ReportType.Marketing, new ProcessingPolicy(ReportType.Marketing, "NoOpFilter", "GzipCompressor", "LocalFileSystemStorage") },
            // Política Inválida (para teste): Interno - SensitiveDataFilter, Gzipar, Local (Viola regra 1: SensitiveDataFilter requer S3Storage)
            { ReportType.Internal, new ProcessingPolicy(ReportType.Internal, "SensitiveDataFilter", "GzipCompressor", "LocalFileSystemStorage") }
        };

        public ProcessingPolicy GetPolicy(ReportType key)
        {
            if (_policies.TryGetValue(key, out var policy))
            {
                return policy;
            }
            throw new KeyNotFoundException($"Nenhuma política encontrada para a chave: {key}");
        }
    }

    public class InMemoryImplementationRepository : IImplementationRepository
    {
        private readonly Dictionary<string, IFilter> _filters = new Dictionary<string, IFilter>
        {
            { "NoOpFilter", new NoOpFilter() },
            { "SensitiveDataFilter", new SensitiveDataFilter() }
        };

        private readonly Dictionary<string, ICompressor> _compressors = new Dictionary<string, ICompressor>
        {
            { "ZipCompressor", new ZipCompressor() },
            { "GzipCompressor", new GzipCompressor() }
        };

        private readonly Dictionary<string, IStorage> _storages = new Dictionary<string, IStorage>
        {
            { "S3Storage", new S3Storage() },
            { "LocalFileSystemStorage", new LocalFileSystemStorage() }
        };

        public IFilter GetFilter(string name)
        {
            if (_filters.TryGetValue(name, out var filter)) return filter;
            throw new KeyNotFoundException($"Implementação de IFilter não encontrada: {name}");
        }

        public ICompressor GetCompressor(string name)
        {
            if (_compressors.TryGetValue(name, out var compressor)) return compressor;
            throw new KeyNotFoundException($"Implementação de ICompressor não encontrada: {name}");
        }

        public IStorage GetStorage(string name)
        {
            if (_storages.TryGetValue(name, out var storage)) return storage;
            throw new KeyNotFoundException($"Implementação de IStorage não encontrada: {name}");
        }
    }
}
