# Fase 12: Composição por Eixos (Orquestradores do Contrato)

## 1. Conceito: Orquestradores do Contrato

A **Composição por Eixos** é um padrão de design que utiliza o conceito de **Orquestradores do Contrato** para construir *pipelines* de processamento complexos a partir de componentes (eixos) independentes e coesos, definidos por interfaces (contratos) [1].

O objetivo é desacoplar a **política** (o que deve ser feito e em que ordem) da **implementação** (como cada passo é executado). O orquestrador atua como o ponto central que recebe uma política e coordena a execução dos eixos.

## 2. Pipeline de Processamento e Eixos Independentes

O pipeline proposto para esta fase é: **Filtrar** → **Comprimir** → **Armazenar**. Cada etapa representa um "eixo" independente, definido por um contrato (interface) específico.

| Eixo (Contrato) | Responsabilidade | Exemplo de Implementação |
| :--- | :--- | :--- |
| `IFilter` | Decidir se o dado deve ser processado. | `NoOpFilter`, `SensitiveDataFilter` |
| `ICompressor` | Reduzir o tamanho do dado. | `ZipCompressor`, `GzipCompressor` |
| `IStorage` | Persistir o dado processado. | `S3Storage`, `LocalFileSystemStorage` |

## 3. Controle por Política

O controle do pipeline é realizado por uma **Política de Processamento** (`ProcessingPolicy`). Esta política é uma estrutura de dados que define a combinação exata de implementações a serem usadas para uma determinada chave de seleção.

A chave de seleção (`PolicyKey`) pode ser baseada em critérios de negócio, como o tipo de relatório (`ReportType`).

| `PolicyKey` (Exemplo) | Implementações Selecionadas | Ordem Esperada |
| :--- | :--- | :--- |
| `ReportType.Financial` | `SensitiveDataFilter`, `ZipCompressor`, `S3Storage` | Filtrar → Comprimir → Armazenar |
| `ReportType.Marketing` | `NoOpFilter`, `GzipCompressor`, `LocalFileSystemStorage` | Filtrar → Comprimir → Armazenar |

O orquestrador (`PipelineOrchestrator`) é injetado com um repositório de políticas (`IPolicyRepository`) e um repositório de implementações (`IImplementationRepository`).

## 4. Seleção por Chave e Rejeição de Combinações Inválidas

### Seleção por Chave

1.  O cliente solicita o processamento de um dado, fornecendo uma `PolicyKey` (ex.: `ReportType.Financial`).
2.  O `PipelineOrchestrator` usa a `PolicyKey` para buscar a `ProcessingPolicy` correspondente no `IPolicyRepository`.
3.  A política retorna os identificadores das implementações necessárias (ex.: "SensitiveDataFilter", "ZipCompressor", "S3Storage").
4.  O orquestrador usa esses identificadores para buscar as instâncias concretas (que implementam `IFilter`, `ICompressor`, `IStorage`) no `IImplementationRepository`.

### Rejeição de Combinações Inválidas

A rejeição de combinações inválidas é uma responsabilidade da **Política**. Isso pode ser implementado em dois níveis:

1.  **Nível de Definição da Política (Tempo de Design):** O `IPolicyRepository` pode ser projetado para garantir que apenas combinações válidas sejam armazenadas. Por exemplo, uma regra pode ser: "Se o filtro for `SensitiveDataFilter`, o armazenamento DEVE ser `S3Storage`".
2.  **Nível de Execução (Tempo de Execução):** O `PipelineOrchestrator` pode conter lógica de validação pós-busca, ou a própria `ProcessingPolicy` pode ter um método de validação. Se a política for inválida (ex.: tentar usar `SensitiveDataFilter` com `LocalFileSystemStorage`), o orquestrador lança uma exceção `InvalidPolicyException` e rejeita a execução.

O foco principal é que a **decisão** sobre o que é válido está concentrada na **Política**, e não espalhada pelo código do orquestrador ou das implementações.

## 5. Estrutura de Código

O código C# será estruturado para demonstrar o desacoplamento:

1.  **Contracts.cs:** Interfaces (`IFilter`, `ICompressor`, `IStorage`, `IPolicyRepository`, `IImplementationRepository`).
2.  **Implementations.cs:** Classes concretas que implementam os eixos.
3.  **Orchestrator.cs:** A classe `PipelineOrchestrator` que orquestra a execução com base na política.

---
### Referências

[1] Guia de Autoestudo: Interfaces em C# - Padrão de Raciocínio: Contratos de Capacidade. (trabalhopoo.pdf)
