using System;
using System.Collections.Generic;
using Xunit;
using Moq;
using OrquestradoresDoContrato.Fase12;

namespace OrquestradoresDoContrato.Fase12.Tests
{
    public class OrchestratorTests
    {
        private readonly Mock<IPolicyRepository> _mockPolicyRepo;
        private readonly Mock<IImplementationRepository> _mockImplRepo;
        private readonly PipelineOrchestrator _orchestrator;

        public OrchestratorTests()
        {
            _mockPolicyRepo = new Mock<IPolicyRepository>();
            _mockImplRepo = new Mock<IImplementationRepository>();
            _orchestrator = new PipelineOrchestrator(_mockPolicyRepo.Object, _mockImplRepo.Object);
        }

        private void SetupValidPolicy(ReportType key, string filter, string compressor, string storage)
        {
            var policy = new ProcessingPolicy(key, filter, compressor, storage);
            _mockPolicyRepo.Setup(r => r.GetPolicy(key)).Returns(policy);

            _mockImplRepo.Setup(r => r.GetFilter(filter)).Returns(new Mock<IFilter>().Object);
            _mockImplRepo.Setup(r => r.GetCompressor(compressor)).Returns(new Mock<ICompressor>().Object);
            _mockImplRepo.Setup(r => r.GetStorage(storage)).Returns(new Mock<IStorage>().Object);
        }

        [Fact]
        public void ProcessData_ShouldExecutePipeline_WhenPolicyIsValid()
        {
            // Arrange
            var policy = new ProcessingPolicy(ReportType.Financial, "F1", "C1", "S1");
            _mockPolicyRepo.Setup(r => r.GetPolicy(ReportType.Financial)).Returns(policy);

            var mockFilter = new Mock<IFilter>();
            mockFilter.Setup(f => f.ShouldProcess(It.IsAny<string>())).Returns(true);
            mockFilter.Setup(f => f.Name).Returns("F1");

            var mockCompressor = new Mock<ICompressor>();
            mockCompressor.Setup(c => c.Compress(It.IsAny<string>())).Returns(new byte[] { 1, 2, 3 });
            mockCompressor.Setup(c => c.Name).Returns("C1");

            var mockStorage = new Mock<IStorage>();
            mockStorage.Setup(s => s.Store(It.IsAny<byte[]>())).Returns("path/to/file");
            mockStorage.Setup(s => s.Name).Returns("S1");

            _mockImplRepo.Setup(r => r.GetFilter("F1")).Returns(mockFilter.Object);
            _mockImplRepo.Setup(r => r.GetCompressor("C1")).Returns(mockCompressor.Object);
            _mockImplRepo.Setup(r => r.GetStorage("S1")).Returns(mockStorage.Object);

            // Act
            var result = _orchestrator.ProcessData(ReportType.Financial, "dados de teste");

            // Assert
            Assert.Equal("path/to/file", result);
            mockFilter.Verify(f => f.ShouldProcess("dados de teste"), Times.Once);
            mockCompressor.Verify(c => c.Compress("dados de teste"), Times.Once);
            mockStorage.Verify(s => s.Store(new byte[] { 1, 2, 3 }), Times.Once);
        }

        [Fact]
        public void ProcessData_ShouldStopIfFilterRejects()
        {
            // Arrange
            var policy = new ProcessingPolicy(ReportType.Financial, "F1", "C1", "S1");
            _mockPolicyRepo.Setup(r => r.GetPolicy(ReportType.Financial)).Returns(policy);

            var mockFilter = new Mock<IFilter>();
            mockFilter.Setup(f => f.ShouldProcess(It.IsAny<string>())).Returns(false); // Rejeita
            mockFilter.Setup(f => f.Name).Returns("F1");

            var mockCompressor = new Mock<ICompressor>();
            mockCompressor.Setup(c => c.Name).Returns("C1");

            var mockStorage = new Mock<IStorage>();
            mockStorage.Setup(s => s.Name).Returns("S1");

            _mockImplRepo.Setup(r => r.GetFilter("F1")).Returns(mockFilter.Object);
            _mockImplRepo.Setup(r => r.GetCompressor("C1")).Returns(mockCompressor.Object);
            _mockImplRepo.Setup(r => r.GetStorage("S1")).Returns(mockStorage.Object);

            // Act
            var result = _orchestrator.ProcessData(ReportType.Financial, "dados de teste");

            // Assert
            Assert.Equal("Processamento Rejeitado", result);
            mockFilter.Verify(f => f.ShouldProcess(It.IsAny<string>()), Times.Once);
            mockCompressor.Verify(c => c.Compress(It.IsAny<string>()), Times.Never); // Não deve comprimir
            mockStorage.Verify(s => s.Store(It.IsAny<byte[]>()), Times.Never); // Não deve armazenar
        }

        [Fact]
        public void ProcessingPolicy_ShouldThrowException_OnInvalidCombination()
        {
            // Arrange
            // Combinação inválida: SensitiveDataFilter com LocalFileSystemStorage
            var invalidPolicy = new ProcessingPolicy(ReportType.Internal, "SensitiveDataFilter", "ZipCompressor", "LocalFileSystemStorage");

            // Act & Assert
            var exception = Assert.Throws<InvalidPolicyException>(() => invalidPolicy.Validate());
            Assert.Contains("SensitiveDataFilter requer S3Storage", exception.Message);
        }

        [Fact]
        public void ProcessData_ShouldThrowException_WhenPolicyIsInvalid()
        {
            // Arrange
            // Configura o repositório para retornar uma política que falhará na validação
            var invalidPolicy = new ProcessingPolicy(ReportType.Internal, "SensitiveDataFilter", "ZipCompressor", "LocalFileSystemStorage");
            _mockPolicyRepo.Setup(r => r.GetPolicy(ReportType.Internal)).Returns(invalidPolicy);

            // Não precisamos configurar os mocks de implementação, pois a exceção deve ocorrer antes
            // de tentar buscar as implementações.

            // Act & Assert
            Assert.Throws<InvalidPolicyException>(() => _orchestrator.ProcessData(ReportType.Internal, "dados de teste"));
        }

        [Fact]
        public void InMemoryPolicyRepository_ShouldReturnPolicy_WhenKeyExists()
        {
            // Arrange
            var repo = new InMemoryPolicyRepository();

            // Act
            var policy = repo.GetPolicy(ReportType.Financial);

            // Assert
            Assert.NotNull(policy);
            Assert.Equal("SensitiveDataFilter", policy.FilterName);
        }

        [Fact]
        public void InMemoryPolicyRepository_ShouldThrowException_WhenKeyDoesNotExist()
        {
            // Arrange
            var repo = new InMemoryPolicyRepository();

            // Act & Assert
            Assert.Throws<KeyNotFoundException>(() => repo.GetPolicy((ReportType)999));
        }

        [Fact]
        public void InMemoryImplementationRepository_ShouldReturnImplementations()
        {
            // Arrange
            var repo = new InMemoryImplementationRepository();

            // Act
            var filter = repo.GetFilter("NoOpFilter");
            var compressor = repo.GetCompressor("GzipCompressor");
            var storage = repo.GetStorage("S3Storage");

            // Assert
            Assert.IsType<NoOpFilter>(filter);
            Assert.IsType<GzipCompressor>(compressor);
            Assert.IsType<S3Storage>(storage);
        }
    }
}
