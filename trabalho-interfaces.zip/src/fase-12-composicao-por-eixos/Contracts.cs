using System;
using System.Collections.Generic;

namespace OrquestradoresDoContrato.Fase12
{
    // --- Exceção de Negócio ---
    public class InvalidPolicyException : Exception
    {
        public InvalidPolicyException(string message) : base(message) { }
    }

    // --- Contratos dos Eixos (Interfaces) ---

    /// <summary>
    /// Contrato para o eixo de Filtragem.
    /// </summary>
    public interface IFilter
    {
        string Name { get; }
        bool ShouldProcess(string data);
    }

    /// <summary>
    /// Contrato para o eixo de Compressão.
    /// </summary>
    public interface ICompressor
    {
        string Name { get; }
        byte[] Compress(string data);
    }

    /// <summary>
    /// Contrato para o eixo de Armazenamento.
    /// </summary>
    public interface IStorage
    {
        string Name { get; }
        string Store(byte[] compressedData);
    }

    // --- Estruturas de Dados de Política ---

    /// <summary>
    /// Chave de seleção para buscar a política.
    /// </summary>
    public enum ReportType
    {
        Financial,
        Marketing,
        Internal
    }

    /// <summary>
    /// Define a política de processamento, especificando as implementações a serem usadas.
    /// </summary>
    public class ProcessingPolicy
    {
        public ReportType Key { get; }
        public string FilterName { get; }
        public string CompressorName { get; }
        public string StorageName { get; }

        public ProcessingPolicy(ReportType key, string filterName, string compressorName, string storageName)
        {
            Key = key;
            FilterName = filterName;
            CompressorName = compressorName;
            StorageName = storageName;
        }

        /// <summary>
        /// Lógica de validação da política (Rejeição de combinações inválidas).
        /// A política é o local para a decisão.
        /// </summary>
        public void Validate()
        {
            // Exemplo de regra de negócio:
            // Se o filtro for SensitiveDataFilter, o armazenamento DEVE ser S3Storage.
            if (FilterName == "SensitiveDataFilter" && StorageName != "S3Storage")
            {
                throw new InvalidPolicyException($"Política inválida para {Key}: SensitiveDataFilter requer S3Storage.");
            }
            
            // Exemplo de regra de negócio 2:
            // Relatórios internos não podem ser comprimidos com Zip.
            if (Key == ReportType.Internal && CompressorName == "ZipCompressor")
            {
                throw new InvalidPolicyException($"Política inválida para {Key}: Relatórios internos não podem usar ZipCompressor.");
            }
        }
    }

    // --- Contratos de Infraestrutura (Repositórios) ---

    /// <summary>
    /// Repositório para buscar as políticas de processamento.
    /// </summary>
    public interface IPolicyRepository
    {
        ProcessingPolicy GetPolicy(ReportType key);
    }

    /// <summary>
    /// Repositório para buscar as instâncias concretas dos eixos.
    /// Simula um contêiner IoC/DI.
    /// </summary>
    public interface IImplementationRepository
    {
        IFilter GetFilter(string name);
        ICompressor GetCompressor(string name);
        IStorage GetStorage(string name);
    }
}
