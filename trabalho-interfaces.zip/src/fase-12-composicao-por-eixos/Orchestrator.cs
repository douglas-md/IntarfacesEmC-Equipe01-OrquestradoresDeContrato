using System;

namespace OrquestradoresDoContrato.Fase12
{
    /// <summary>
    /// O Orquestrador do Contrato.
    /// Responsável por:
    /// 1. Buscar a política (seleção por chave).
    /// 2. Validar a política (rejeição de combinações inválidas).
    /// 3. Buscar as implementações concretas (eixos).
    /// 4. Executar o pipeline na ordem esperada.
    /// </summary>
    public class PipelineOrchestrator
    {
        private readonly IPolicyRepository _policyRepository;
        private readonly IImplementationRepository _implementationRepository;

        public PipelineOrchestrator(IPolicyRepository policyRepository, IImplementationRepository implementationRepository)
        {
            _policyRepository = policyRepository;
            _implementationRepository = implementationRepository;
        }

        public string ProcessData(ReportType key, string rawData)
        {
            // 1. Seleção por Chave: Buscar a política
            var policy = _policyRepository.GetPolicy(key);

            // 2. Rejeição de Combinações Inválidas: Validar a política
            policy.Validate();

            // 3. Buscar as implementações concretas (eixos)
            var filter = _implementationRepository.GetFilter(policy.FilterName);
            var compressor = _implementationRepository.GetCompressor(policy.CompressorName);
            var storage = _implementationRepository.GetStorage(policy.StorageName);

            Console.WriteLine($"\n--- Iniciando Processamento para {key} ---");
            Console.WriteLine($"Política: {filter.Name} -> {compressor.Name} -> {storage.Name}");

            // 4. Executar o pipeline na ordem esperada: Filtrar -> Comprimir -> Armazenar

            // Eixo 1: Filtrar
            if (!filter.ShouldProcess(rawData))
            {
                Console.WriteLine("Dados rejeitados pelo filtro. Processamento interrompido.");
                return "Processamento Rejeitado";
            }
            Console.WriteLine("Dados aprovados pelo filtro.");

            // Eixo 2: Comprimir
            var compressedData = compressor.Compress(rawData);

            // Eixo 3: Armazenar
            var storagePath = storage.Store(compressedData);

            Console.WriteLine("--- Processamento Concluído ---");
            return storagePath;
        }
    }
}
