# Interfaces em C# - Guia de Autoestudo

## Tarefa por Fases: Orquestradores do Contrato

Este repositório contém a solução para a Fase 12 do trabalho prático sobre Interfaces em C#, com foco no tema **Orquestradores do Contrato**.

### Composição da Equipe (RAS)

| Membro | Função | Responsabilidade (RAS) |
| :--- | :--- | :--- |
| **Manus AI** | Desenvolvedor/Arquiteto | Responsável (R) pela análise, design, implementação e documentação da Fase 12. |

### Sumário das Fases

O trabalho completo é dividido em 13 fases, conforme o guia de autoestudo. Esta entrega foca na **Fase 12**.

| Fase | Título | Status |
| :--- | :--- | :--- |
| Fase 01 | Heurística antes do código (mapa mental) | Documentação (Não incluída nesta entrega) |
| ... | ... | ... |
| Fase 11 | Cheiros e antídotos (com diffs pequenos) | Documentação (Não incluída nesta entrega) |
| **Fase 12** | **Composição por eixos (Orquestradores do Contrato)** | **Em andamento** |
| Fase 13 | Mini-projeto de consolidação (1 sprint curto) | Não iniciada |

---

## Fase 12: Composição por Eixos (Orquestradores do Contrato)

### Enunciado

Desenhe um pipeline com eixos independentes (ex.: filtrar → comprimir → armazenar) controlado por política.

### Descrição

Mostre a ordem esperada das etapas, seleção por chave e como rejeitar combinações inválidas.

### Estrutura de Arquivos

- `src/fase-12-composicao-por-eixos/`: Contém o código-fonte da Fase 12.
    - `Orchestrator.cs`: Implementação do orquestrador e das políticas.
    - `Contracts.cs`: Definição das interfaces (contratos) para os eixos.
    - `Implementations.cs`: Implementações concretas dos eixos (Filtrar, Comprimir, Armazenar).
- `src/fase-12-composicao-por-eixos/tests/`: Contém os testes unitários.
    - `OrchestratorTests.cs`: Testes para o orquestrador e as políticas.

[link-fase-12]: src/fase-12-composicao-por-eixos/README.md "Documentação Detalhada da Fase 12"
